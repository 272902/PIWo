export default function Footer() {
    return (
        <footer>
            <span className="email center">Książkarnia - księgarnia internetowa </span>
        </footer>
    );
}