import { createContext, useContext, useState } from "react";

const BooksContext = createContext();

export function BooksProvider({ children }) {
  const [books, setBooks] = useState([
    { id: 1, title: "Wiedźmin", author: "Andrzej Sapkowski", category: "Fantasy" },
    { id: 2, title: "Lalka", author: "Bolesław Prus", category: "Społeczno-obyczajowa" },
    { id: 3, title: "Pan Tadeusz", author: "Adam Mickiewicz", category: "Poemat" },
    { id: 4, title: "Dziady", author: "Adam Mickiewicz", category: "Dramat" },
  ]);

  const addBook = (book) => {
    setBooks(prev => [...prev, { ...book, id: Date.now() }]);
  };

  const removeBook = (id) => {
    setBooks(prev => prev.filter(book => book.id !== id));
  };

  return (
    <BooksContext.Provider value={{ books, addBook, removeBook }}>
      {children}
    </BooksContext.Provider>
  );
}

export function useBooks() {
  return useContext(BooksContext);
}
